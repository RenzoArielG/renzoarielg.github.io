import pygame
import random

# Colores
BLANCO = (255, 255, 255)
NEGRO = (0, 0, 0)
VERDE = (0, 200, 0)
ROJO = (200, 0, 0)
AZUL_CLARO = (50, 150, 200)
VERDE_CLARO = (0, 255, 0)
ROJO_CLARO = (255, 50, 50)

# Dimensiones
ANCHO = 800
ALTO = 600

# Inicialización de Pygame y sonido
pygame.init()
try:
    pygame.mixer.init()
    pygame.mixer.music.load("C:/Users/Rengo/Desktop/Actividades Curso Programacion/Juego Dados/Alwa's Awakening.mp3")
    pygame.mixer.music.play(-1)
    pygame.mixer.music.set_volume(0.5)
except Exception as e:
    print("No se pudo inicializar o cargar música:", e)

pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Juego de Dados")
reloj = pygame.time.Clock()
fuente = pygame.font.SysFont(None, 36)

# Carga de imágenes de dados
imagenes_dados = [pygame.image.load(f"C:/Users/Rengo/Desktop/Actividades Curso Programacion/Juego Dados/dado{i}.png") for i in range(1, 7)]
imagenes_dados_muestra = [pygame.image.load(f"C:/Users/Rengo/Desktop/Actividades Curso Programacion/Juego Dados/dadomuestra{i}.png") for i in range(1, 7)]

# Variables del juego
estado = {
    "jugador_dados": [],
    "cpu_dados": [],
    "jugador_suma": 0,
    "cpu_suma": 0,
    "turno": "jugador",
    "resultado": "",
    "dado_animando": False,
    "tiempo_animacion": 0,
    "dado_random": 1,
    "dado_final": 1,
    "ultimo_cambio": 0,
    "cpu_animando": False,
    "tiempo_cpu_animacion": 0,
    "cpu_dado_random": 1,
    "cpu_dado_final": 1,
    "cpu_ultimo_cambio": 0,
    "intervalo_cambio": 50,
    "pantalla": "inicio",  # inicio | opciones | juego | dificultad
    "dificultad": "medio",
    "jugador_puntos": 0,
    "cpu_puntos": 0,
}

# Reiniciar juego
def reiniciar_juego():
    estado["jugador_dados"] = []
    estado["cpu_dados"] = []
    estado["jugador_suma"] = 0
    estado["cpu_suma"] = 0
    estado["turno"] = "jugador"
    estado["resultado"] = ""
    estado["dado_animando"] = False
    estado["tiempo_animacion"] = 0
    estado["dado_random"] = 1
    estado["dado_final"] = 1
    estado["ultimo_cambio"] = 0
    estado["cpu_animando"] = False
    estado["tiempo_cpu_animacion"] = 0
    estado["cpu_dado_random"] = 1
    estado["cpu_dado_final"] = 1
    estado["cpu_ultimo_cambio"] = 0
    estado["jugador_puntos"] = 0
    estado["cpu_puntos"] = 0

# Tirar dado
def tirar_dado():
    return random.randint(1, 6)

# Turno jugador
def turno_jugador():
    if not estado["dado_animando"] and estado["jugador_suma"] < 10:
        estado["dado_final"] = tirar_dado()
        estado["dado_animando"] = True
        estado["tiempo_animacion"] = pygame.time.get_ticks()
        estado["ultimo_cambio"] = estado["tiempo_animacion"]
        estado["dado_random"] = random.randint(1, 6)

# Turno CPU
def turno_cpu():
    if not estado["cpu_animando"]:
        if estado["cpu_suma"] < 10:
            debe_tirar = False
            # Lógica según dificultad
            if estado["dificultad"] == "facil":
                if estado["cpu_suma"] < 5:
                    debe_tirar = True
                elif estado["cpu_suma"] < 9 and estado["jugador_suma"] > estado["cpu_suma"]:
                    debe_tirar = random.choice([True, False])
            elif estado["dificultad"] == "medio":
                if estado["cpu_suma"] < 6:
                    debe_tirar = True
                elif estado["cpu_suma"] < 9 and estado["jugador_suma"] > estado["cpu_suma"]:
                    debe_tirar = random.choice([True, False])
            elif estado["dificultad"] == "dificil":
                if estado["cpu_suma"] < 7:
                    debe_tirar = True
                elif estado["cpu_suma"] < 10 and estado["jugador_suma"] > estado["cpu_suma"]:
                    debe_tirar = True
            if debe_tirar:
                estado["cpu_dado_final"] = tirar_dado()
                estado["cpu_animando"] = True
                estado["tiempo_cpu_animacion"] = pygame.time.get_ticks()
                estado["cpu_ultimo_cambio"] = estado["tiempo_cpu_animacion"]
                estado["cpu_dado_random"] = random.randint(1, 6)
            else:
                evaluar_ronda()
        else:
            evaluar_ronda()
    else:
        tiempo_actual = pygame.time.get_ticks()
        if tiempo_actual - estado["cpu_ultimo_cambio"] >= estado["intervalo_cambio"]:
            estado["cpu_dado_random"] = random.randint(1, 6)
            estado["cpu_ultimo_cambio"] = tiempo_actual
        if tiempo_actual - estado["tiempo_cpu_animacion"] >= 1000:
            estado["cpu_animando"] = False
            estado["cpu_dados"].append(estado["cpu_dado_final"])
            estado["cpu_suma"] += estado["cpu_dado_final"]
            if estado["cpu_suma"] >= 10 or len(estado["cpu_dados"]) >= 10:
                evaluar_ronda()

# Evaluar ronda
def evaluar_ronda():
    if estado["jugador_suma"] > 10 and estado["cpu_suma"] > 10:
        estado["resultado"] = "¡Ambos se pasaron!"
    elif estado["jugador_suma"] > 10:
        estado["resultado"] = "¡Jugador se pasó! Gana CPU"
        estado["cpu_puntos"] += 1
    elif estado["cpu_suma"] > 10:
        estado["resultado"] = "¡CPU se pasó! Gana Jugador"
        estado["jugador_puntos"] += 1
    elif estado["jugador_suma"] > estado["cpu_suma"]:
        estado["resultado"] = "¡Gana el Jugador!"
        estado["jugador_puntos"] += 1
    elif estado["cpu_suma"] > estado["jugador_suma"]:
        estado["resultado"] = "¡Gana la CPU!"
        estado["cpu_puntos"] += 1
    else:
        estado["resultado"] = "¡Empate!"
    estado["turno"] = "fin"

# Dibujar dado
def dibujar_dado(x, y, valor, tamaño=60, muestra=False):
    if muestra:
        imagen = pygame.transform.scale(imagenes_dados_muestra[valor-1], (tamaño, tamaño))
    else:
        imagen = pygame.transform.scale(imagenes_dados[valor-1], (tamaño, tamaño))
    pantalla.blit(imagen, (x, y))

# Dibujar botón
def dibujar_boton(x, y, ancho, alto, color, texto_str):
    mouse_x, mouse_y = pygame.mouse.get_pos()
    if x <= mouse_x <= x+ancho and y <= mouse_y <= y+alto:
        color_actual = VERDE_CLARO if color == VERDE else ROJO_CLARO
    else:
        color_actual = color
    sombra = (max(color_actual[0]-50, 0), max(color_actual[1]-50, 0), max(color_actual[2]-50, 0))
    pygame.draw.rect(pantalla, sombra, (x+4, y+4, ancho, alto), border_radius=12)
    pygame.draw.rect(pantalla, color_actual, (x, y, ancho, alto), border_radius=12)
    texto = fuente.render(texto_str, True, BLANCO)
    pantalla.blit(texto, (x + (ancho - texto.get_width()) // 2, y + (alto - texto.get_height()) // 2))

# --- PANTALLA DE INICIO ---
def dibujar_inicio():
    pantalla.fill(AZUL_CLARO)
    titulo = fuente.render("Juego de Dados", True, BLANCO)
    pantalla.blit(titulo, (ANCHO//2 - titulo.get_width()//2, 120))
    dibujar_boton(ANCHO//2 - 85, 200, 170, 50, VERDE, "Jugar")
    dibujar_boton(ANCHO//2 - 85, 270, 170, 50, VERDE, "Opciones")
    dibujar_boton(ANCHO//2 - 85, 340, 170, 50, ROJO, "Salir")

# --- PANTALLA DE OPCIONES ---
def dibujar_opciones():
    pantalla.fill(AZUL_CLARO)
    titulo = fuente.render("Opciones", True, BLANCO)
    pantalla.blit(titulo, (ANCHO//2 - titulo.get_width()//2, 120))
    if pygame.mixer.music.get_busy():
        dibujar_boton(ANCHO//2 - 85, 200, 170, 50, VERDE, "Musica: ON")
    else:
        dibujar_boton(ANCHO//2 - 85, 200, 170, 50, ROJO, "Musica: OFF")
    dibujar_boton(ANCHO//2 - 140, 270, 80, 50, NEGRO, "Vol +")
    dibujar_boton(ANCHO//2 + 60, 270, 80, 50, NEGRO, "Vol -")
    dibujar_boton(ANCHO//2 - 85, 340, 170, 50, ROJO, "Volver")

# --- PANTALLA DE DIFICULTAD ---
def dibujar_dificultad():
    pantalla.fill(AZUL_CLARO)
    titulo = fuente.render("Selecciona Dificultad", True, BLANCO)
    pantalla.blit(titulo, (ANCHO//2 - titulo.get_width()//2, 120))
    dibujar_boton(ANCHO//2 - 85, 200, 170, 50, VERDE, "Fácil")
    dibujar_boton(ANCHO//2 - 85, 270, 170, 50, VERDE, "Medio")
    dibujar_boton(ANCHO//2 - 85, 340, 170, 50, VERDE, "Difícil")
    dibujar_boton(ANCHO//2 - 85, 410, 170, 50, ROJO, "Volver")

# --- PANTALLA DE JUEGO MODIFICADA ---
def dibujar_juego():
    pantalla.fill(AZUL_CLARO)

    # Puntos acumulados
    pantalla.blit(fuente.render(f"Puntos Jugador: {estado['jugador_puntos']}", True, BLANCO), (20, 20))
    pantalla.blit(fuente.render(f"Puntos CPU: {estado['cpu_puntos']}", True, BLANCO), (20, 60))

    # Botón volver
    dibujar_boton(ANCHO - 180, 20, 160, 40, ROJO, "Atras")

    # Dados jugador
    for i, valor in enumerate(estado["jugador_dados"]):
        dibujar_dado(50 + i*70, 170, valor, 60, muestra=True)

    # Dados CPU
    for i, valor in enumerate(estado["cpu_dados"]):
        dibujar_dado(50 + i*70, 300, valor, 60, muestra=True)

    # Animación jugador
    if estado["turno"] == "jugador" and estado["dado_animando"]:
        tiempo_actual = pygame.time.get_ticks()
        if tiempo_actual - estado["ultimo_cambio"] >= estado["intervalo_cambio"]:
            estado["dado_random"] = random.randint(1, 6)
            estado["ultimo_cambio"] = tiempo_actual
        dibujar_dado(480, 140, estado["dado_random"], 80, muestra=False)
        if tiempo_actual - estado["tiempo_animacion"] >= 1000:
            estado["dado_animando"] = False
            estado["jugador_dados"].append(estado["dado_final"])
            estado["jugador_suma"] += estado["dado_final"]
            if estado["jugador_suma"] >= 10:
                estado["turno"] = "cpu"

    # Animación CPU
    if estado["turno"] == "cpu" and estado["cpu_animando"]:
        tiempo_actual = pygame.time.get_ticks()
        if tiempo_actual - estado["cpu_ultimo_cambio"] >= estado["intervalo_cambio"]:
            estado["cpu_dado_random"] = random.randint(1, 6)
            estado["cpu_ultimo_cambio"] = tiempo_actual
        dibujar_dado(480, 210, estado["cpu_dado_random"], 80, muestra=False)
        if tiempo_actual - estado["tiempo_cpu_animacion"] >= 1000:
            estado["cpu_animando"] = False
            estado["cpu_dados"].append(estado["cpu_dado_final"])
            estado["cpu_suma"] += estado["cpu_dado_final"]
            if estado["cpu_suma"] >= 10 or len(estado["cpu_dados"]) >= 10:
                evaluar_ronda()

    pantalla.blit(fuente.render(f"Jugador: {estado['jugador_suma']}", True, BLANCO), (50, 140))
    pantalla.blit(fuente.render(f"CPU: {estado['cpu_suma']}", True, BLANCO), (50, 270))

    if estado["turno"] == "jugador" and not estado["dado_animando"] and estado["jugador_suma"] < 10:
        dibujar_boton(480, 140, 170, 50, VERDE, "Tirar dado")
        dibujar_boton(480, 210, 170, 50, ROJO, "Plantarse")

    if estado["turno"] == "fin":
        texto_r = fuente.render(estado["resultado"], True, BLANCO)
        pantalla.blit(texto_r, (ANCHO//2 - texto_r.get_width()//2, 500))  

# --- Manejo de eventos ---
def manejar_eventos():
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            return False
        if evento.type == pygame.MOUSEBUTTONDOWN:
            x, y = evento.pos
            # Pantalla inicio
            if estado["pantalla"] == "inicio":
                if ANCHO//2 - 85 <= x <= ANCHO//2 + 85:
                    if 200 <= y <= 250:
                        estado["pantalla"] = "dificultad"
                    elif 270 <= y <= 320:
                        estado["pantalla"] = "opciones"
                    elif 340 <= y <= 390:
                        return False
            # Pantalla opciones
            elif estado["pantalla"] == "opciones":
                if ANCHO//2 - 85 <= x <= ANCHO//2 + 85 and 200 <= y <= 250:
                    if pygame.mixer.music.get_busy():
                        pygame.mixer.music.pause()
                    else:
                        pygame.mixer.music.unpause()
                elif ANCHO//2 - 140 <= x <= ANCHO//2 - 60 and 270 <= y <= 320:
                    vol = pygame.mixer.music.get_volume()
                    pygame.mixer.music.set_volume(min(1.0, vol + 0.1))
                elif ANCHO//2 + 60 <= x <= ANCHO//2 + 140 and 270 <= y <= 320:
                    vol = pygame.mixer.music.get_volume()
                    pygame.mixer.music.set_volume(max(0.0, vol - 0.1))
                elif ANCHO//2 - 85 <= x <= ANCHO//2 + 85 and 340 <= y <= 390:
                    estado["pantalla"] = "inicio"
            # Pantalla dificultad
            elif estado["pantalla"] == "dificultad":
                if ANCHO//2 - 85 <= x <= ANCHO//2 + 85:
                    if 200 <= y <= 250:
                        estado["dificultad"] = "facil"
                        reiniciar_juego()
                        estado["pantalla"] = "juego"
                    elif 270 <= y <= 320:
                        estado["dificultad"] = "medio"
                        reiniciar_juego()
                        estado["pantalla"] = "juego"
                    elif 340 <= y <= 390:
                        estado["dificultad"] = "dificil"
                        reiniciar_juego()
                        estado["pantalla"] = "juego"
                    elif 410 <= y <= 460:
                        estado["pantalla"] = "inicio"
            # Pantalla juego
            elif estado["pantalla"] == "juego":
                if ANCHO - 180 <= x <= ANCHO - 20 and 20 <= y <= 60:
                    reiniciar_juego()
                    estado["pantalla"] = "inicio"
                if estado["turno"] == "jugador" and not estado["dado_animando"]:
                    if 480 <= x <= 650 and 140 <= y <= 190:
                        turno_jugador()
                    elif 480 <= x <= 650 and 210 <= y <= 260:
                        estado["turno"] = "cpu"
                if estado["turno"] == "fin":
                    reiniciar_juego()
    return True

# --- Actualizar CPU ---
def actualizar():
    if estado["pantalla"] == "juego" and estado["turno"] == "cpu":
        turno_cpu()

# --- Bucle principal ---
ejecutando = True
while ejecutando:
    reloj.tick(60)
    ejecutando = manejar_eventos()
    actualizar()
    if estado["pantalla"] == "inicio":
        dibujar_inicio()
    elif estado["pantalla"] == "opciones":
        dibujar_opciones()
    elif estado["pantalla"] == "dificultad":
        dibujar_dificultad()
    elif estado["pantalla"] == "juego":
        dibujar_juego()
    pygame.display.flip()

pygame.quit()